$(function() { //JQUERY

	$('#my-menu').mmenu({
		extensions: [ 'widescreen', 'theme-black', 'effect-menu-slide', 'pagedim-black'],
		navbar: { 
			title: '<img src="img/logo-1.svg" alt="Салон красоты Смитлер">' //Для того, чтобы вместо MENU был логотип. Это круто.
		},
		offCanvas: {
			position: 'right' //Для того, чтобы меню выезжало СПРАВА. 
		}
	}); //Селектор, подключение mmenu! (Посмотри extensions!)

var api = $('#my-menu').data('mmenu'); //Выбор селектора и еще что-то. Синтаксис javascript.
api.bind('opened', function() {
	$('.hamburger--emphatic').addClass('is-active');  //Если меню открыто, то изменяем кнопку гамбургера.
}).bind('closed', function(){
	$('.hamburger--emphatic').removeClass('is-active');
})

$('.carousel-services').on('initialized.owl.carousel', function() { //все ровненько и красиво для карусели. 
	setTimeout(function() {
		carouselService();
	}, 100);
});
$('.carousel-services').owlCarousel({
	loop: true,  //зацикливаем карусель
	nav: true,  //Навигация. Предыдущий, следующий.
	smartSpeed: 700, //Скорость карусели.
	navText: ['<i class="fas fa-angle-double-left"></i>', '<i class="fas fa-angle-double-right"></i>'],
	responsiveClass: true, 
	dots: false, 
	responsive: {
		0: {
			items: 1
		},
		800: {
			items: 2
		},
		1100: {
			items: 3
		}
	}
});

$('.carousel-services-list').equalHeights();

function carouselService() { //Чтобы картинка была такого же размера как и штуки с сервисом. JQUERY
	$('.carousel-services-item').each(function() {
		var ths = $(this),
		thsh = ths.find('.carousel-services-content').outerHeight();
		ths.find('.carousel-services-image').css('min-height', thsh); 
	});
}carouselService();

$('.carousel-services-composition .h3').each(function() {
	var ths = $(this);
	ths.html(ths.html().replace(/(\S+)\s*$/, '<span>$1</span>')); //регулярное выражение. последнее слово выделено в span
});

//Resize Windows
function onResize() { //выравнивается при каждом ресайзе.
	$('.carousel-services-content').equalHeights();
}onResize();
window.onresize = function() {
	onResize()
};


});
